# AWS Cloud Internship Projects

This repository contains the Beginner and Intermediate AWS Cloud internship projects.

## Beginner
Student Feedback Portal:
S3 -> Lambda Function URL -> Lambda

## Intermediate
Service Request Portal:
S3 -> API Gateway -> Lambda -> DynamoDB

The Intermediate project implements both data creation (POST) and data retrieval (GET).
